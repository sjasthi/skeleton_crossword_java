package com.example.driver;

import java.awt.Dimension;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;

import org.apache.poi.hslf.usermodel.HSLFSlide;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.json.JSONArray;
import org.json.JSONObject;

import com.example.APIConnector.APIConnector;
import com.example.powerpoint.Powerpoint;
import com.example.skeleton.Letter;
import com.example.skeleton.SkeletonBoard;
import com.example.skeleton.Word;
import com.example.wordReader.wordReader;

public class Driver {

	/**
	 * 
	 */

	public static void main(String[] args) {


		/**
		 * Check Perferences.java for the default values
		 *  "E:\\Folders\\Classes\\ICS499\\Files\\"
		 *  "E:\\Folders\\Classes\\ICS499\\Workspace\\ICS499-Skeleton_Project\\docs\\" 
		 */
		Preferences settings = new Preferences();
		settings.setLanguage("english");
		settings.setMaxNumberOfWords(80);
		settings.setMaxNumberOfPuzzles(1);
		settings.setOutputFolderLocation("E:\\Folders\\Classes\\ICS499\\Powerpoints\\");

		/**
		 * wordList will contain the words that the reader object has read. logicalChars
		 * holds the Letter objects of each word
		 */
		ArrayList<String> wordList = new ArrayList<String>();
		ArrayList<Letter> logicalChars = new ArrayList<Letter>();
		Iterator wordIterator = wordList.iterator();

		/**
		 * wordReader object reads the words contained in the word_list and adds it to
		 * the arrayList wordList
		 */
		wordReader reader = new wordReader(settings.getWordListFolderLocation() + settings.getWordListFileName());
		reader.readFileIntoArray(wordList);

		/**
		 * board represents the skeleton board that will be played on.
		 */
		SkeletonBoard board = new SkeletonBoard();

		board.findBoardSize();
		board.fillBoardWithSpaces();

		Powerpoint solutionsPpt = new Powerpoint();
		solutionsPpt.getPpt().setPageSize(new Dimension(1400, 1800));
		Powerpoint puzzlesPpt = new Powerpoint();
		puzzlesPpt.getPpt().setPageSize(new Dimension(1400, 1800));

		int slideCount = 0;
		int numOfPuzzles = 0;
		int repeat = 0;

//		Collections.shuffle(wordList);
		Iterator<String> itr = wordList.iterator();
		while (itr.hasNext() && numOfPuzzles < settings.getMaxNumberOfPuzzles()) {
			String currentWord = itr.next();
			APIConnector connector = new APIConnector(currentWord);
			connector.getLogicalChars();
			try {
				int responseCode = connector.getConnection().getResponseCode();
				if (responseCode != 200) {
					throw new RuntimeException("HttpResponseCode: " + responseCode);
				} else {
					InputStream inputStream = connector.getConnection().getInputStream();
					Scanner scanner = new Scanner(inputStream);
					String line = new String();
					while (scanner.hasNextLine()) {
						line = scanner.nextLine();
						line = line.substring(line.indexOf("{"));
					}

					JSONObject jsonObj = new JSONObject(line);
					JSONArray jsonArray = jsonObj.getJSONArray("data");

					logicalChars = new ArrayList<Letter>();

					Word word = new Word(currentWord, logicalChars, -1, -1, "none");
					for (int k = 0; k < jsonArray.length(); k++) {
						Letter letter = new Letter(-1, -1, jsonArray.getString(k), word);
						logicalChars.add(letter);
					}
					if (board.insertToBoard(logicalChars, word)) {
						wordList.removeAll(Collections.singleton(currentWord));
						itr = wordList.iterator();
						repeat = 0;
					} else {
						Collections.shuffle(wordList);
						itr = wordList.iterator();
						repeat++;
					}

					if (repeat == 100) {
						System.out.println("Repeat");
						Collections.shuffle(wordList);
						itr = wordList.iterator();
						board = new SkeletonBoard();
						board.findBoardSize();
						board.fillBoardWithSpaces();

//						break;
					}

					if (board.getNumberOfWords() == settings.getMaxNumberOfWords()) {
						HSLFSlide puzzleSlides = puzzlesPpt.createSlide(++slideCount);
						HSLFSlide solutionsSlides = solutionsPpt.createSlide(slideCount);
						puzzlesPpt.createPuzzleTable(puzzleSlides, board.getBoard().length, board.getBoard().length,
								board.getBoard());
						puzzlesPpt.createAvailableLetters(puzzleSlides, board);
						puzzlesPpt.writePuzzles(puzzlesPpt.getPpt(),
								settings.getOutputFolderLocation() + settings.getPuzzleFileName());
						puzzlesPpt.getPpt().close();

						solutionsPpt.createSolutionTable(solutionsSlides, board.getBoard().length,
								board.getBoard().length, board.getBoard());
						solutionsPpt.createAvailableLetters(solutionsSlides, board);
						solutionsPpt.writeSolutions(solutionsPpt.getPpt(),
								settings.getOutputFolderLocation() + settings.getSolutionFileName());
						solutionsPpt.getPpt().close();
						numOfPuzzles++;
						board = new SkeletonBoard();
						board.findBoardSize();
						board.fillBoardWithSpaces();
					}

				}
				connector.disconnect(connector.getConnection());
			} catch (IOException e) {
				e.printStackTrace();
			}

		}


	}

}
