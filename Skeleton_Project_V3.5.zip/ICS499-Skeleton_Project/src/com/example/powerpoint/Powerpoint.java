package com.example.powerpoint;

import java.awt.Color;
import java.awt.Rectangle;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collections;

import org.apache.poi.hslf.usermodel.HSLFShape;
import org.apache.poi.hslf.usermodel.HSLFSlide;
import org.apache.poi.hslf.usermodel.HSLFSlideShow;
import org.apache.poi.hslf.usermodel.HSLFTable;
import org.apache.poi.hslf.usermodel.HSLFTableCell;
import org.apache.poi.hslf.usermodel.HSLFTextBox;
import org.apache.poi.hslf.usermodel.HSLFTextParagraph;
import org.apache.poi.hslf.usermodel.HSLFTextRun;
import org.apache.poi.hwpf.usermodel.Table;
import org.apache.poi.sl.usermodel.VerticalAlignment;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.apache.poi.xslf.usermodel.XSLFSlideShow;
import org.apache.poi.xslf.usermodel.XSLFTable;
import org.apache.poi.xwpf.usermodel.XWPFTable;

import com.example.skeleton.Letter;
import com.example.skeleton.SkeletonBoard;

import org.apache.poi.sl.usermodel.TableCell.BorderEdge;

public class Powerpoint {
	private HSLFSlideShow ppt;
	
	
	public Powerpoint() {
		ppt = new HSLFSlideShow();
		
	}
	
	public HSLFSlide createSlide(int count) {
		HSLFSlide slide = this.ppt.createSlide();
		HSLFTextBox title = slide.createTextBox();
		HSLFTextParagraph p = title.getTextParagraphs().get(0);
		HSLFTextRun r = p.getTextRuns().get(0);
		r.setFontColor(Color.black);
		r.setText("Skeleton Puzzle #" + count);
		r.setBold(true);
		r.setFontSize(24.0);
		title.setAnchor(new Rectangle(0, 10, 1400, 40));
		title.moveTo(0, 10);
		return slide;
	}
	
	public HSLFTable createSolutionTable(HSLFSlide slide, int row, int col, Letter[][] board) {
		HSLFTable table = slide.createTable(row, col);
		table.setAnchor(new Rectangle(0,60,1600,1800));
//		System.out.println(table.getInteriorAnchor());
//		table.moveTo(203, 60);
		for (int i = 0; i < table.getNumberOfColumns(); i++) {
			table.setColumnWidth(i, 35);
		}

		for (int i = 0; i < table.getNumberOfRows(); i++) {
			table.setRowHeight(i,35);
		}
		
		for(int i = 0; i < table.getNumberOfRows(); i++) {
			for(int k = 0; k < table.getNumberOfColumns(); k++) {
				
				HSLFTableCell cell = table.getCell(i, k);
				cell.setVerticalAlignment(VerticalAlignment.MIDDLE);
				cell.setHorizontalCentered(true);
				cell.setText(board[i][k].getLetter().toUpperCase());
				if(!cell.getText().equalsIgnoreCase(" ")) {
					cell.setBorderColor(BorderEdge.top, Color.black);
					cell.setBorderColor(BorderEdge.right, Color.black);
					cell.setBorderColor(BorderEdge.bottom, Color.black);
					cell.setBorderColor(BorderEdge.left, Color.black);
				}

			}
		}
		return table;
	}
	
	public HSLFTable createPuzzleTable(HSLFSlide slide, int row, int col, Letter[][] board) {
		HSLFTable table = slide.createTable(row, col);
		table.setAnchor(new Rectangle(0,60,1600,1800));
		
//		table.moveTo(203, 60);
//		System.out.println(table.getAnchor());
		
		for (int i = 0; i < table.getNumberOfColumns(); i++) {
			table.setColumnWidth(i, 35);
		}

		for (int i = 0; i < table.getNumberOfRows(); i++) {
			table.setRowHeight(i,35);
		}
		
		for(int i = 0; i < table.getNumberOfRows(); i++) {
			for(int k = 0; k < table.getNumberOfColumns(); k++) {
				HSLFTableCell cell = table.getCell(i, k);
				cell.setVerticalAlignment(VerticalAlignment.MIDDLE);
				cell.setHorizontalCentered(true);
				if(!board[i][k].getLetter().equalsIgnoreCase(" ")) {
					cell.setText(" ");
				}else {
					cell.setText(board[i][k].getLetter());
				}
				
				if(!board[i][k].getLetter().equalsIgnoreCase(" ")) {
					cell.setBorderColor(BorderEdge.top, Color.black);
					cell.setBorderColor(BorderEdge.right, Color.black);
					cell.setBorderColor(BorderEdge.bottom, Color.black);
					cell.setBorderColor(BorderEdge.left, Color.black);
				}

			}
		}
		return table;
	}
	
	public void createAvailableLetters(HSLFSlide slide, SkeletonBoard board) {
		Collections.shuffle(board.getLettersOnBoard());
		HSLFTextBox textBox = slide.createTextBox();
		for(int letterObject = 0; letterObject < board.getLettersOnBoard().size(); letterObject++) {
			textBox.appendText(board.getLettersOnBoard().get(letterObject).getLetter().toUpperCase(), false);
			textBox.appendText(",", false);
		}
		textBox.setAnchor(new Rectangle(0,100,1400,50));
		textBox.moveTo(0, 1500);
		textBox.setAlignToBaseline(true);
		
	}
	


	public void writeSolutions(HSLFSlideShow ppt,String fileName) {
		try {
			FileOutputStream out = new FileOutputStream("E:\\Folders\\Classes\\ICS499\\Powerpoints\\"+fileName+".ppt");
			ppt.write(out);
			out.close();
			ppt.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void writePuzzles(HSLFSlideShow ppt,String fileName) {
		try {
			FileOutputStream out = new FileOutputStream("E:\\Folders\\Classes\\ICS499\\Powerpoints\\"+fileName+".ppt");
			ppt.write(out);
			out.close();
			ppt.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	public HSLFSlideShow getPpt() {
		return ppt;
	}

	public void setPpt(HSLFSlideShow ppt) {
		this.ppt = ppt;
	}
	
}