package com.example.driver;

public class Preferences {
	private int maxNumberOfWords;
	private int maxNumberOfPuzzles;
	private String language;
	private String wordListFileName;
	private String puzzleFileName;
	private String solutionFileName;
	private String outputFolderLocation;
	private String wordListFolderLocation;

	public Preferences() {
		
		maxNumberOfWords = 5;
		maxNumberOfPuzzles = 10;
		language = ("english");
		puzzleFileName = (language + "_skeleton_puzzle.ppt");
		solutionFileName = (language + "_skeleton_solution.ppt");
		wordListFileName = (language + "_word_list.csv");
		outputFolderLocation = ("E:\\Folders\\Classes\\ICS499\\Files\\");
		wordListFolderLocation = ("E:\\Folders\\Classes\\ICS499\\Workspace\\ICS499-Skeleton_Project\\docs\\");

	}

	public int getMaxNumberOfWords() {
		return maxNumberOfWords;
	}

	public void setMaxNumberOfWords(int maxNumberOfWords) {
		this.maxNumberOfWords = maxNumberOfWords;
	}

	public int getMaxNumberOfPuzzles() {
		return maxNumberOfPuzzles;
	}

	public void setMaxNumberOfPuzzles(int maxNumberOfPuzzles) {
		this.maxNumberOfPuzzles = maxNumberOfPuzzles;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
		puzzleFileName = (language + "_skeleton_puzzle.ppt");
		solutionFileName = (language + "_skeleton_solution.ppt");
		wordListFileName = (language + "_word_list.csv");
	}

	public String getWordListFileName() {
		return wordListFileName;
	}

	public void setWordListFileName(String wordListFileName) {
		this.wordListFileName = wordListFileName;
	}

	public String getPuzzleFileName() {
		return puzzleFileName;
	}

	public void setPuzzleFileName(String puzzleFileName) {
		this.puzzleFileName = puzzleFileName;
	}

	public String getSolutionFileName() {
		return solutionFileName;
	}

	public void setSolutionFileName(String solutionFileName) {
		this.solutionFileName = solutionFileName;
	}

	public String getOutputFolderLocation() {
		return outputFolderLocation;
	}

	public void setOutputFolderLocation(String outputFolderLocation) {
		this.outputFolderLocation = outputFolderLocation;
	}

	public String getWordListFolderLocation() {
		return wordListFolderLocation;
	}

	public void setWordListFolderLocation(String wordListFolderLocation) {
		this.wordListFolderLocation = wordListFolderLocation;
	}
	
	
	
	


}
