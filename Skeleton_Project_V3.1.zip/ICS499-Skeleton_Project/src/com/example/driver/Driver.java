package com.example.driver;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;

import org.apache.poi.hslf.usermodel.HSLFSlide;
import org.json.JSONArray;
import org.json.JSONObject;

import com.example.APIConnector.APIConnector;
import com.example.powerpoint.Powerpoint;
import com.example.skeleton.Letter;
import com.example.skeleton.SkeletonBoard;
import com.example.skeleton.Word;
import com.example.wordReader.wordReader;

public class Driver {

	public static void main(String[] args) {

		/**
		 * These variables represent the settings for the board. wordMax set the
		 * maximum number of words on the board and language sets the language of the
		 * words between english and telugu.
		 */
		int wordMax = 3;
		String language = "telugu";

		/**
		 * wordList will contain the words that the reader object has read. logicalChars
		 * holds the Letter objects of each word
		 */
		ArrayList<String> wordList = new ArrayList<String>();
		ArrayList<Letter> logicalChars = new ArrayList<Letter>();
		Iterator wordIterator = wordList.iterator();

		/**
		 * wordReader object reads the words contained in the word_list and adds it to
		 * the arrayList wordList
		 */
		wordReader reader = new wordReader("E:\\Folders\\Classes\\ICS499\\Files\\" + language + "_word_list.csv");
		reader.readFileIntoArray(wordList);

		/**
		 * board represents the skeleton board that will be played on.
		 */
		SkeletonBoard board = new SkeletonBoard();

//		Collections.sort(board.getWordList());
		board.findBoardSize();
		board.fillBoardWithSpaces();

		Powerpoint solutionsPpt = new Powerpoint();
		Powerpoint puzzlesPpt = new Powerpoint();
		int slideCount = 0;

		
		
		for (int i = 0; i < wordList.size() && !wordList.isEmpty(); i++) {
			APIConnector connector = new APIConnector(wordList.get(i));
			connector.getLogicalChars();
			try {
				int responseCode = connector.getConnection().getResponseCode();
				if (responseCode != 200) {
					throw new RuntimeException("HttpResponseCode: " + responseCode);
				} else {
					InputStream inputStream = connector.getConnection().getInputStream();
					Scanner scanner = new Scanner(inputStream);
					String line = new String();
					while (scanner.hasNextLine()) {
						line = scanner.nextLine();
						line = line.substring(line.indexOf("{"));
					}

					JSONObject jsonObj = new JSONObject(line);
					JSONArray jsonArray = jsonObj.getJSONArray("data");

					logicalChars = new ArrayList<Letter>();

					Word word = new Word(wordList.get(i), logicalChars, -1, -1, "none");
					for (int k = 0; k < jsonArray.length(); k++) {
						Letter letter = new Letter(-1, -1, jsonArray.getString(k), word);
						logicalChars.add(letter);
					}

					board.insertToBoard(logicalChars, word);
//					if(board.insertToBoard(logicalChars, word)) {
//						wordList.removeAll(Collections.singleton(wordList.get(i)));
//						System.out.println(wordList.toString());
//					}
//					if(i == wordList.size() - 1 && !wordList.isEmpty()) {
//						i = 0;
//					}
					
					
					
					if(board.getNumberOfWords() == wordMax) {
						HSLFSlide puzzleSlides = puzzlesPpt.createSlide(++slideCount);
						HSLFSlide solutionsSlides = solutionsPpt.createSlide(slideCount);
						puzzlesPpt.createPuzzleTable(puzzleSlides, board.getBoard().length, board.getBoard().length, board.getBoard());
						puzzlesPpt.createAvailableLetters(puzzleSlides, board);
						puzzlesPpt.writePuzzles(puzzlesPpt.getPpt(), language + "_skeleton_puzzle");
						puzzlesPpt.getPpt().close();
						
						solutionsPpt.createSolutionTable(solutionsSlides, board.getBoard().length, board.getBoard().length, board.getBoard());
						solutionsPpt.createAvailableLetters(solutionsSlides, board);
						solutionsPpt.writeSolutions(solutionsPpt.getPpt(), language + "_skeleton_solution");
						solutionsPpt.getPpt().close();
						board = new SkeletonBoard();
						board.findBoardSize();
						board.fillBoardWithSpaces();
					}
					
					

				}
				connector.disconnect(connector.getConnection());
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

	}

}
