package com.example.driver;

import java.awt.Color;
import java.sql.Timestamp;

public class Preferences {

	private static long now = System.currentTimeMillis();
	
	private static Timestamp timestamp = new Timestamp(now);
	
	public static String directory = System.getProperty("user.dir"); // = E:\Folders\Classes\ICS499\Workspace\ICS499-Skeleton_Project

	public final static int MAX_NUMBER_OF_WORDS = 3;

	public final static int MAX_NUMBER_OF_PUZZLES = 3;

	public final static String WORD_LIST_FILE_NAME = directory + "/docs/english_word_list.csv";

	public final static String PUZZLE_FILE_NAME = "english_skeleton_puzzle_" + timestamp.getNanos()/10000 + ".ppt";

	public final static String SOLUTION_FILE_NAME = "english_skeleton_solution_" + timestamp.getNanos()/10000 + ".ppt";

	public final static String OUTPUT_FOLDER_LOCATION = directory + "/PowerPoints/";

	public final static String WORD_LIST_FOLDER_LOCATION = directory + "/docs/";

	public final static Color TABLE_FONT_COLOR = Color.black;

	public final static boolean TABLE_FONT_BOLD = true;

	public final static Color TABLE_BORDER_COLOR = Color.black;

	public final static Color TABLE_BORDER_INPLAY_COLOR = Color.RED;

	public final static Color TABLE_BORDER_NOTINPLAY_COLOR = Color.black;

	public final static Color TABLE_BACKGROUND_COLOR = Color.LIGHT_GRAY;
	
	public final static Color SLIDE_NUMBER_COLOR = Color.blue;
	
	public final static double SLIDE_NUMBER_FONTSIZE = 45.0;
	
	public final static boolean SLIDE_NUMBER_FONTBOLD = true;

	/**
	 * Changing the settings below will require user to adjust table to fit onto
	 * slides.
	 */

	public final static double TABLE_FONT_SIZE = 21.0;

	public final static int SLIDE_WIDTH = 1400;

	public final static int SLIDE_HEIGHT = 900;

	public final static int BOARD_ROW = 15;

	public final static int BOARD_COL = 20;

}
