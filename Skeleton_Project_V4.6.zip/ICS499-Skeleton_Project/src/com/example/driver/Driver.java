package com.example.driver;

import java.awt.Desktop;
import java.awt.Dimension;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;

import org.apache.poi.hslf.usermodel.HSLFSlide;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.json.JSONArray;
import org.json.JSONObject;

import com.example.APIConnector.APIConnector;
import com.example.powerpoint.Powerpoint;
import com.example.skeleton.Letter;
import com.example.skeleton.SkeletonBoard;
import com.example.skeleton.Word;
import com.example.wordReader.WordReader;

public class Driver {

	/**
	 * 
	 */

	public static void main(String[] args) {

		/**
		 * wordList will contain the words that the reader object has read. logicalChars
		 * holds the Letter objects of each word
		 */
		ArrayList<String> wordList = new ArrayList<String>();
		ArrayList<Letter> logicalChars = new ArrayList<Letter>();

		/**
		 * wordReader object reads the words contained in the word_list and adds it to
		 * the arrayList wordList
		 */
		WordReader reader = new WordReader(Preferences.WORD_LIST_FILE_NAME);
		reader.readFileIntoArray(wordList);

		/**
		 * board represents the skeleton board that will be played on.
		 */
		SkeletonBoard board = new SkeletonBoard();

		board.findBoardSize(Preferences.BOARD_ROW, Preferences.BOARD_COL);
		board.fillBoardWithSpaces();

		Powerpoint solutionsPpt = new Powerpoint();
		solutionsPpt.getPpt().setPageSize(new Dimension(Preferences.SLIDE_WIDTH, Preferences.SLIDE_HEIGHT));
		Powerpoint puzzlesPpt = new Powerpoint();
		puzzlesPpt.getPpt().setPageSize(new Dimension(Preferences.SLIDE_WIDTH, Preferences.SLIDE_HEIGHT));

		int slideCount = 0;
		int numOfPuzzles = 0;
		int repeat = 0;

		Collections.shuffle(wordList);
		long start = System.currentTimeMillis();

		Iterator<String> itr = wordList.iterator();
		while (itr.hasNext() && numOfPuzzles < Preferences.MAX_NUMBER_OF_PUZZLES) {
			String currentWord = itr.next();
			APIConnector connector = new APIConnector(currentWord);
			connector.getLogicalChars();
			try {
				int responseCode = connector.getConnection().getResponseCode();
				if (responseCode != 200) {
					throw new RuntimeException("HttpResponseCode: " + responseCode);
				} else {
					InputStream inputStream = connector.getConnection().getInputStream();
					Scanner scanner = new Scanner(inputStream);
					String line = new String();
					while (scanner.hasNextLine()) {
						line = scanner.nextLine();
						line = line.substring(line.indexOf("{"));
					}

					JSONObject jsonObj = new JSONObject(line);
					JSONArray jsonArray = jsonObj.getJSONArray("data");

					logicalChars = new ArrayList<Letter>();

					Word word = new Word(currentWord, logicalChars, -1, -1, "none");
					for (int k = 0; k < jsonArray.length(); k++) {
						Letter letter = new Letter(-1, -1, jsonArray.getString(k), word);
						logicalChars.add(letter);
					}
					if (board.insertToBoard(logicalChars, word)) {
						wordList.removeAll(Collections.singleton(currentWord));
						itr = wordList.iterator();
						repeat = 0;
					} else {
						Collections.shuffle(wordList);
						itr = wordList.iterator();
						repeat++;
					}

					if (repeat == 100) {
						System.out.println("Repeat");
						Collections.shuffle(wordList);
						itr = wordList.iterator();
						board = new SkeletonBoard();
						board.findBoardSize(Preferences.BOARD_ROW, Preferences.BOARD_COL);
						board.fillBoardWithSpaces();

					}

					if (board.getNumberOfWords() == Preferences.MAX_NUMBER_OF_WORDS) {
						HSLFSlide puzzleSlides = puzzlesPpt.createSlide(++slideCount);
						HSLFSlide solutionsSlides = solutionsPpt.createSlide(slideCount);
						puzzlesPpt.createPuzzleTable(puzzleSlides, board.getBoard().length, board.getBoard().length,
								board.getBoard());
						puzzlesPpt.createAvailableLetters(puzzleSlides, board);
						puzzlesPpt.writePuzzles(puzzlesPpt.getPpt(),
								Preferences.OUTPUT_FOLDER_LOCATION + Preferences.PUZZLE_FILE_NAME);
						puzzlesPpt.getPpt().close();

						solutionsPpt.createSolutionTable(solutionsSlides, board.getBoard().length,
								board.getBoard().length, board.getBoard());
						solutionsPpt.writeSolutions(solutionsPpt.getPpt(),
								Preferences.OUTPUT_FOLDER_LOCATION + Preferences.SOLUTION_FILE_NAME);
						solutionsPpt.getPpt().close();
						numOfPuzzles++;
						board = new SkeletonBoard();
						board.findBoardSize(Preferences.BOARD_ROW, Preferences.BOARD_COL);
						board.fillBoardWithSpaces();
					}

				}
				connector.disconnect(connector.getConnection());
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		long end = System.currentTimeMillis();
		float seconds = (end - start) / 1000F;
		System.out.println("DONE! It took " + seconds + " Seconds");

		File solPPT = new File(Preferences.OUTPUT_FOLDER_LOCATION + Preferences.SOLUTION_FILE_NAME);
		File puzPPT = new File(Preferences.OUTPUT_FOLDER_LOCATION + Preferences.PUZZLE_FILE_NAME);
		Desktop dt = Desktop.getDesktop();
		if (solPPT.exists() && puzPPT.exists()) {
			try {
				dt.open(solPPT);
				dt.open(puzPPT);
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

	}

}
